import React from "react";

export function Guid() {
    return(
        <div>
            Guid test
        </div>
    );
}