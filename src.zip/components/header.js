import React from "react";
import { Link } from "react-router-dom";

export function Header() {
    return(
        <nav>
            <Link to="/">홈</Link>
            <Link to="/scanfood">음식 스캔하기</Link>
            <Link to="/nowcarbon">현재 탄소량</Link>
            <Link to="/guidpage">가이드</Link>
            <Link to="/mypage">MY</Link>
        </nav>
    );
}