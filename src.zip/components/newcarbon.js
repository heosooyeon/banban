import React from "react";


export function Newcarbon() {
    return(
        <div>
            Newcarbon test
        </div>
    );
}