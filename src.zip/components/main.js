import React from "react";

export function Main() {
    return(
        <div>
            main 화면
        </div>
    );
}