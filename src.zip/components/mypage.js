import React from "react";

export function My() {
    return(
        <div>My page</div>
    );
}